# -*- coding: utf-8 -*-
"""
Created on Sat Sep 21 21:55:24 2024

@author: David
"""

for x in range(1,10):
    print(x)
    x = x
    