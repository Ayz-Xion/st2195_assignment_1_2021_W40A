for (x in 1:10){
    print(x)
    x = x+1
    }

